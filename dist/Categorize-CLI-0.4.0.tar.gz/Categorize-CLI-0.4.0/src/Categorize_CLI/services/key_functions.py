import os
import collections
import re
from src.Categorize_CLI.extensions import *
from src.Categorize_CLI.secondary_functions import *
import time
from datetime import timedelta


# Group 2: Organize files based on name
def name_category(folder_to_track):
    movedFiles = False
    count = 0
    start_time = time.monotonic()
    file_mappings = collections.defaultdict()
    delimiters = ['.', ',', '!', ' ', '-', ';', '?', '*', '!', '@', '#', '$', '%', '^', '&', '(', ')', '_', '/', '|','<', '>']
    sub_file_names = []
    file_names = []
    regexPattern = '|'.join(map(re.escape, delimiters))

    for filename in os.listdir(folder_to_track):
        filename = filename.lower()
        file_names.append(filename)
        sub_file_names = find_common_keyword(file_names)

    if check_files(folder_to_track):
        for file in os.listdir(folder_to_track):
            if not os.path.isdir(os.path.join(folder_to_track, file)):
                try:
                    for filename in os.listdir(folder_to_track):
                        if not os.path.isdir(os.path.join(folder_to_track, filename)):
                            for sub_file_name in sub_file_names:
                                file_mappings.setdefault(sub_file_name, []).append(filename)

                    for folder_name, folder_items in file_mappings.items():
                        folder_path = os.path.join(folder_to_track, folder_name)
                        folder_exists = os.path.exists(folder_path)
                        if not folder_exists:
                            os.mkdir(folder_path)

                            for filename in file_names:
                                filename = filename.lower()
                                splittedstring = re.split(regexPattern, filename, 0)
                                if folder_name in splittedstring:
                                    count = count + 1
                                    source = os.path.join(folder_to_track, filename)
                                    destination = os.path.join(folder_path, filename)
                                    moveIncrementing(source, destination)
                                    movedFiles = True

                        if folder_exists:
                            for filename in file_names:
                                filename = filename.lower()
                                splittedstring = re.split(regexPattern, filename, 0)
                                if folder_name in splittedstring and not os.path.isdir(
                                        os.path.join(folder_to_track, filename)):
                                    count = count + 1
                                    source = os.path.join(folder_to_track, filename)
                                    destination = os.path.join(folder_path, filename)
                                    moveIncrementing(source, destination)
                                    movedFiles = True

                    for filename in os.listdir(folder_to_track):
                        if not os.path.isdir(os.path.join(folder_to_track, filename)):
                            file_mappings.setdefault('other', []).append(filename)

                    for folder_name, folder_items in file_mappings.items():
                        folder_path = os.path.join(folder_to_track, folder_name)
                        folder_exists = os.path.exists(folder_path)

                        if not folder_exists:
                            os.mkdir(folder_path)

                            for filename in os.listdir(folder_to_track):
                                filename = filename.lower()
                                if not os.path.isdir(os.path.join(folder_to_track, filename)):
                                    count = count + 1
                                    source = os.path.join(folder_to_track, filename)
                                    destination = os.path.join(folder_path, filename)
                                    moveIncrementing(source, destination)
                                    movedFiles = True

                    end_time = time.monotonic()

                    displayProgressbar(count)

                    if movedFiles:
                        if count == 1:
                            return f"Successfully moved {count} file{os.linesep}Time taken: {timedelta(seconds=end_time - start_time)}"
                        else:
                            return f"Successfully moved {count} files{os.linesep}Time taken: {timedelta(seconds=end_time - start_time)}"
                    else:
                        return f"{folder_to_track}: is either empty or not organizable"

                except Exception as e:
                    return f'{folder_to_track}: is either empty or not organizable'
    else:
        return f'{folder_to_track}: is either empty or not organizable'


def specific_name_category(keyword, folder_to_track):
    start_time = time.monotonic()
    movedFiles = False
    count = 0
    file_mappings = collections.defaultdict()
    file_names = []
    keyword = keyword.lower()
    delimiters = ['.', ',', '!', ' ', '-', ';', '?', '*', '!', '@', '#', '$', '%', '^', '&', '(', ')', '_', '/', '|','<', '>']
    regexPattern = '|'.join(map(re.escape, delimiters))

    if check_files(folder_to_track):
        for file in os.listdir(folder_to_track):
            if not os.path.isdir(os.path.join(folder_to_track, file)):
                try:
                    for filename in os.listdir(folder_to_track):
                        filename = filename.lower()
                        file_names.append(filename)

                    for filename in os.listdir(folder_to_track):
                        filename = filename.lower()
                        splittedstring = re.split(regexPattern, filename, 0)
                        if not os.path.isdir(os.path.join(folder_to_track, filename)) and keyword in splittedstring:
                            file_mappings.setdefault(keyword, []).append(filename)

                    for folder_name, folder_items in file_mappings.items():
                        folder_path = os.path.join(folder_to_track, folder_name)
                        folder_exists = os.path.exists(folder_path)
                        if not folder_exists:
                            os.mkdir(folder_path)

                            for filename in file_names:
                                filename = filename.lower()
                                splittedstring = re.split(regexPattern, filename, 0)
                                if folder_name in splittedstring:
                                    count = count + 1
                                    source = os.path.join(folder_to_track, filename)
                                    destination = os.path.join(folder_path, filename)
                                    moveIncrementing(source, destination)
                                    movedFiles = True

                        if folder_exists:
                            for filename in file_names:
                                filename = filename.lower()
                                splittedstring = re.split(regexPattern, filename, 0)
                                if folder_name in splittedstring and not os.path.isdir(
                                        os.path.join(folder_to_track, filename)):
                                    count = count + 1
                                    source = os.path.join(folder_to_track, filename)
                                    destination = os.path.join(folder_path, filename)
                                    moveIncrementing(source, destination)
                                    movedFiles = True

                    end_time = time.monotonic()

                    displayProgressbar(count)

                    if movedFiles:
                        if count == 1:
                            return f"Successfully moved {count} file{os.linesep}Time taken: {timedelta(seconds=end_time - start_time)}"
                        else:
                            return f"Successfully moved {count} files{os.linesep}Time taken: {timedelta(seconds=end_time - start_time)}"
                    else:
                        return f"{folder_to_track}: is either empty or not organizable"

                except Exception as e:
                    return f'{folder_to_track}: is either empty or not organizable'
    else:
        return f'{folder_to_track}: is either empty or not organizable'